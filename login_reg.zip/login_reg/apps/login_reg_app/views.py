from django.shortcuts import render, HttpResponse, redirect
from .models import User
# validation v
from django.contrib import messages 

def index(request):
    request.session = 0
    if request.method=="POST":
        redirect('/register')
    return render(request,'login_reg_app/index.html')

def index_register(request):
    errors = User.objects.validations(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        x = User.objects.create(first_name=request.POST['first_name'],last_name=request.POST['last_name'],email=request.POST['email'],password=request.POST['password'])
        request.session['id'] = x.id
        return redirect("/success")

def index_login(request):
    errors = User.objects.validations(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        x = User.objects.get(email=request.POST['email'])
        request.session['id'] = x.id
        return redirect("/success")

def index_success(request):
    #cn also save user data in session
    if request.method=="POST" or request.session != 0:
        x = User.objects.get(id=request.session['id'])
        context = {
            "name": x.first_name
        }
        return render(request,'login_reg_app/index_success.html',context)
    else:
        return redirect("/")

def index_logout(request):
    request.session = 0
    return redirect("/")
